smtps = "mail.smtp2go.com"
port = "2525"
username = "tizabiharo@hotelnextmail.com"
password = "6YTS5297AVm2"
